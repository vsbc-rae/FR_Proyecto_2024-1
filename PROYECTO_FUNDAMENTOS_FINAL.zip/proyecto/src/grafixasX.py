#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

# Read data from files
data_xact = np.loadtxt('/home/fabrizio/xactual.txt')
data_xdes = np.loadtxt('/home/fabrizio/xdeseado.txt')

# Extract time and positions
t = data_xact[:,0]
x_act = data_xact[:,1]
y_act = data_xact[:,2]
z_act = data_xact[:,3]

x_des = data_xdes[:,1]
y_des = data_xdes[:,2]
z_des = data_xdes[:,3]

# Create the 3 subplots for X, Y, Z positions
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 10))

# Plot X position
ax1.plot(t, x_act, 'r-', label='Actual')
ax1.plot(t, x_des, 'g--', label='Desired')
ax1.set_xlabel('Time [s]')
ax1.set_ylabel('X Position [m]')
ax1.grid(True)
ax1.legend()

# Plot Y position
ax2.plot(t, y_act, 'r-', label='Actual')
ax2.plot(t, y_des, 'g--', label='Desired')
ax2.set_xlabel('Time [s]')
ax2.set_ylabel('Y Position [m]')
ax2.grid(True)
ax2.legend()

# Plot Z position
ax3.plot(t, z_act, 'r-', label='Actual')
ax3.plot(t, z_des, 'g--', label='Desired')
ax3.set_xlabel('Time [s]')
ax3.set_ylabel('Z Position [m]')
ax3.grid(True)
ax3.legend()

plt.tight_layout()
plt.savefig('xyz_positions.png')
plt.show()
