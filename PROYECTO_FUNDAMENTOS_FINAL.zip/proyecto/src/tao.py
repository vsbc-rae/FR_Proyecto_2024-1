#!/usr/bin/env python3

import rospy
import numpy as np
from sensor_msgs.msg import JointState
from markers import BallMarker, color
from functions import kr20_fkine2
import rbdl

if __name__ == '__main__':
    rospy.init_node("control_pdg")

    # Publicador ROS
    pub = rospy.Publisher('joint_states', JointState, queue_size=1000)
    bmarker_actual = BallMarker(color['RED'])
    bmarker_deseado = BallMarker(color['GREEN'])

    # Nombres de las articulaciones
    jnames = ['base__link01', 'link01__link02', 'link02__link02_copy', 
              'link02_copy__link03', 'link03__link04', 'link04__link05', 'link05__gripper']
    
    # Configuración inicial
    q = np.array([0.5, 0.2, 0.3, 0.0, 0.6, 0.1, 0.0])  # Configuración articular
    dq = np.array([0.8, 0.7, 0.6, 0.9, 1.0, 0.1, 0.0])  # Velocidades articulares
    ddq = np.array([0.2, 0.4, 0.3, 0.1, 0.5, 0.1, 0.0])  # Aceleraciones articulares

    # Modelo RBDL
    modelo = rbdl.loadModel('/home/fabrizio/lab_ws/src/proyecto/urdf/kuka.urdf')
    ndof = modelo.q_size  # Grados de libertad
    M = np.zeros([ndof, ndof])  # Matriz de inercia
    C = np.zeros(ndof)  # Vector de fuerzas de Coriolis
    g = np.zeros(ndof)  # Vector de fuerzas gravitacionales

    # Cálculo de las dinámicas
    rbdl.CompositeRigidBodyAlgorithm(modelo, q, M)  # Matriz de inercia
    rbdl.NonlinearEffects(modelo, q, dq, C)         # Coriolis y gravedad
    rbdl.InverseDynamics(modelo, q, dq, ddq, g)    # Fuerzas gravitacionales

    # Torque total
    tau = M.dot(ddq) + C

    # Mostrar resultados en consola
    print("\nConfiguración articular (q):")
    print(q)
    print("\nVelocidades articulares (dq):")
    print(dq)
    print("\nAceleraciones articulares (ddq):")
    print(ddq)

    print("\nMatriz de inercia (M):")
    print(M)
    print("\nVector de fuerzas de Coriolis (C):")
    print(C - g)  # Resta para aislar efectos de Coriolis
    print("\nVector de fuerzas gravitatorias (g):")
    print(g)
    print("\nTorque total (tau):")
    print(tau)

    # Publicación de posiciones articulares en ROS
    jstate = JointState()
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames
    jstate.position = q
    pub.publish(jstate)

    # Marcas visuales (opcional)
    xdes = kr20_fkine2(q)[0:3, 3]  # Posición deseada
    bmarker_actual.xyz(xdes)