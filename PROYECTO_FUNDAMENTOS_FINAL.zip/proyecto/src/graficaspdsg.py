
#!/usr/bin/env python3
import matplotlib.pyplot as plt
import numpy as np

# Load data from files
data_qact = np.loadtxt('/home/fabrizio/qactual.txt')
data_qdes = np.loadtxt('/home/fabrizio/qdeseado.txt')
time = data_qact[:,0]

# Create subplots for each joint
fig, axs = plt.subplots(7, 1, figsize=(10, 14))
fig.suptitle('Joint Positions vs Time')

# Plot each joint position
for i in range(7):
    axs[i].plot(time, data_qact[:,i], 'b-', label=f'q{i+1} actual')
    axs[i].plot(time, data_qdes[:,i], 'r--', label=f'q{i+1} desired')
    axs[i].set_ylabel(f'Joint {i+1} [rad]')
    axs[i].grid(True)
    axs[i].legend()

# Set common x label
axs[6].set_xlabel('Time [s]')

plt.tight_layout()
plt.show()