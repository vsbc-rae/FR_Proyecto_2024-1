import numpy as np
from copy import copy
import matplotlib.pyplot as plt

cos=np.cos; sin=np.sin; pi=np.pi


def dh(d, theta, a, alpha):
 T = np.array([
        [np.cos(theta), -np.sin(theta) * np.cos(alpha), np.sin(theta) * np.sin(alpha), a * np.cos(theta)],
        [np.sin(theta), np.cos(theta) * np.cos(alpha), -np.cos(theta) * np.sin(alpha), a * np.sin(theta)],
        [0, np.sin(alpha), np.cos(alpha), d],
        [0, 0, 0, 1]
    ])
 return T
    
    

def fkine(q):
    dh_params = [
        (0.5,  q[0]+pi,    -0.15,  pi/2),     # 
        (-0.2, q[1]+pi/2,  0.785,  0),       #
        (0.15, -q[2],      0.785,  0),    #     
        (0.05, -q[3]+pi,   -0.17,  pi/2),         
        (0.87, q[4]+pi,    -0.025, pi/2),  
        (0,    -q[5]+pi,   0,      pi/2),             
        (0.15, q[6],       -0.03,  0)                   
    ]

    # Matrices de transformación DH para cada articulación
    T1 = dh(*dh_params[0])
    T2 = dh(*dh_params[1])
    T3 = dh(*dh_params[2])
    T4 = dh(*dh_params[3])
    T5 = dh(*dh_params[4])
    T6 = dh(*dh_params[5])
    T7 = dh(*dh_params[6])

    # Transformación del efector final respecto a la base
    T = T1 @ T2 @ T3 @ T4 @ T5 @ T6 @ T7

    return T

def ikine_with_convergence(xdes, q0):
    epsilon = 0.001
    max_iter = 1000
    q = copy(q0)
    errors = []

    for _ in range(max_iter):
        error = xdes - fkine(q)[:3, 3]
        errors.append(np.linalg.norm(error))
        if np.linalg.norm(error) < epsilon:
            break

        J = jacobian(q)
        delta_q = np.linalg.lstsq(J, error, rcond=None)[0]
        q += delta_q

    return q, errors


def plot_convergence(errors):
    plt.plot(errors, label="Error de convergencia")
    plt.title("Convergencia del algoritmo IK")
    plt.xlabel("Iteración")
    plt.ylabel("Error (norma)")
    plt.grid()
    plt.legend()
    plt.show()


def generate_and_verify_configurations():
    # Configuración inicial
    q0 = np.zeros(7)

    # Posición deseada
    x_des1 = np.array([0.3, 0.2, 0.5])
    x_des2 = np.array([0.1, -0.1, 0.4])

    # Cinemática inversa con convergencia
    q_ik1, errors1 = ikine_with_convergence(x_des1, q0)
    q_ik2, errors2 = ikine_with_convergence(x_des2, q0)

    # Verificación con FK
    pos_verif1 = fkine(q_ik1)[:3, 3]
    pos_verif2 = fkine(q_ik2)[:3, 3]

    print("\nConfiguración 1:")
    print(f"Posición deseada: {x_des1}")
    print(f"Posición obtenida: {pos_verif1}")
    print(f"Configuración articular: {q_ik1}")

    print("\nConfiguración 2:")
    print(f"Posición deseada: {x_des2}")
    print(f"Posición obtenida: {pos_verif2}")
    print(f"Configuración articular: {q_ik2}")

    # Graficar convergencia
    plot_convergence(errors1)
    plot_convergence(errors2)


def jacobian(q, delta=0.0001):
 """
 Jacobiano analitico para la posicion de un brazo robotico de n grados de libertad. 
 Retorna una matriz de 3xn y toma como entrada el vector de configuracion articular 
 q=[q1, q2, q3, ..., qn]
 """
 # Crear una matriz 3xn
 n = q.size
 J = np.zeros((3,n))
 # Calcular la transformacion homogenea inicial (usando q)
 T = fkine(q)
    
 # Iteracion para la derivada de cada articulacion (columna)
 for i in range(n):
  # Copiar la configuracion articular inicial
  dq = copy(q)
  # Calcular nuevamenta la transformacion homogenea e
  # Incrementar la articulacion i-esima usando un delta
  dq[i] += delta
  # Transformacion homogenea luego del incremento (q+delta)
  T_inc = fkine(dq)
  # Aproximacion del Jacobiano de posicion usando diferencias finitas
  J[0:3,i]=(T_inc[0:3,3]-T[0:3,3])/delta
 return J


def ikine(xdes, q0):
    """
    Calcular la cinematica inversa de UR5 numericamente a partir de la configuracion articular inicial de q0.
    Emplear el metodo de newton
    """
    epsilon  = 0.001
    max_iter = 1000
    delta    = 0.00001

    q  = copy(q0)
    for _ in range(max_iter):
        # Calcular el error
        error = xdes - fkine(q)[:3, 3]

        # Si el error es suficientemente pequeño, terminar la iteración
        if np.linalg.norm(error) < epsilon:
            break

        # Calcular la matriz jacobiana en q
        J = jacobian(q)

        # Calcular el incremento de q usando el método de Newton
        delta_q = np.linalg.lstsq(J, error, rcond=None)[0]

        # Actualizar q
        q += delta_q

    return q


def ik_gradient(xdes, q0):
 """
 Calcular la cinematica inversa de un brazo robotico numericamente a partir 
 de la configuracion articular inicial de q0. Emplear el metodo gradiente.
 """
 epsilon  = 0.001
 max_iter = 1000
 delta    = 0.00001

 q  = copy(q0)
 for i in range(max_iter):
  # Main loop
  pass
    
 return q

    
def rot2quat(R):
 """
 Convertir una matriz de rotacion en un cuaternion

 Entrada:
  R -- Matriz de rotacion
 Salida:
  Q -- Cuaternion [ew, ex, ey, ez]

 """
 dEpsilon = 1e-6
 quat = 4*[0.,]

 quat[0] = 0.5*np.sqrt(R[0,0]+R[1,1]+R[2,2]+1.0)
 if ( np.fabs(R[0,0]-R[1,1]-R[2,2]+1.0) < dEpsilon ):
  quat[1] = 0.0
 else:
  quat[1] = 0.5*np.sign(R[2,1]-R[1,2])*np.sqrt(R[0,0]-R[1,1]-R[2,2]+1.0)
 if ( np.fabs(R[1,1]-R[2,2]-R[0,0]+1.0) < dEpsilon ):
  quat[2] = 0.0
 else:
  quat[2] = 0.5*np.sign(R[0,2]-R[2,0])*np.sqrt(R[1,1]-R[2,2]-R[0,0]+1.0)
 if ( np.fabs(R[2,2]-R[0,0]-R[1,1]+1.0) < dEpsilon ):
  quat[3] = 0.0
 else:
  quat[3] = 0.5*np.sign(R[1,0]-R[0,1])*np.sqrt(R[2,2]-R[0,0]-R[1,1]+1.0)

 return np.array(quat)


def TF2xyzquat(T):
 """
 Convert a homogeneous transformation matrix into the a vector containing the
 pose of the robot.

 Input:
  T -- A homogeneous transformation
 Output:
  X -- A pose vector in the format [x y z ew ex ey ez], donde la first part
       is Cartesian coordinates and the last part is a quaternion
 """
 quat = rot2quat(T[0:3,0:3])
 res = [T[0,3], T[1,3], T[2,3], quat[0], quat[1], quat[2], quat[3]]
 return np.array(res)
