#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import JointState
from markers import *
from lab5functions import *
import numpy as np

if __name__ == '__main__':

    # Inicialización de nodo ROS
    rospy.init_node("testInvKine")
    pub = rospy.Publisher('joint_states', JointState, queue_size=1)
    bmarker = BallMarker(color['RED'])
    bmarker_des = BallMarker(color['GREEN'])

    # Archivos donde se almacenarán los datos
    fqact = open("/home/fabrizio/qactual.txt", "w")
    fqdes = open("/home/fabrizio/qdeseado.txt", "w")
    fxact = open("/home/fabrizio/xactual.txt", "w")
    fxdes = open("/home/fabrizio/xdeseado.txt", "w")

    # Nombres de las articulaciones
    jnames = ['base_link01', 'link01link02', 'link02link02_copy', 'link02_copy_link03',
              'link03_link04', 'link04link05', 'link05_gripper']

    # Posición deseada
    xd = np.array([1.5, -1, 1.149])
    # Configuración inicial
    q0 = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    # Cinemática inversa
    q = ikine_with_convergence(xd, q0)

    # Posición resultante (efector final respecto a la base)
    T = fkine(q[0])
    print('Valor obtenido:\n', np.round(T, 3))

    # Marcadores para las posiciones alcanzadas y deseadas
    bmarker.xyz(T[0:3, 3])
    bmarker_des.xyz(xd)

    # Objeto de tipo JointState
    jstate = JointState()
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames
    jstate.position = q

    # Frecuencia de ejecución (en Hz)
    rate = rospy.Rate(100)
    t = 0.0  # Tiempo inicial

    # Bucle de ejecución continua
    while not rospy.is_shutdown():
     # Marca de tiempo actual
     jstate.header.stamp = rospy.Time.now()

     # Calcular posición actual
     x = T[0:3, 3]

     # Validar y escribir datos de q
     if len(q) == 7:
         q_float = [float(value) for value in q]  # Asegurar que los valores sean flotantes
         fqact.write(f"{t} {q[0]} {q[1]} {q[2]} {q[3]} {q[4]} {q[5]} {q[6]}\n")
         jstate.position = q_float  # Asignar q_float a jstate.position
     else:
         rospy.logerr(f"q no tiene el tamaño esperado (7). Tamaño actual: {len(q)}. Valor de q: {q}")
         fqact.write(f"{t} ERROR: q no tiene 7 elementos. Valor actual: {q}\n")

     # Almacenamiento de posición deseada y actual
     fxact.write(f"{t} {x[0]} {x[1]} {x[2]}\n")
     fxdes.write(f"{t} {xd[0]} {xd[1]} {xd[2]}\n")
     fqdes.write(f"{t} {q0[0]} {q0[1]} {q0[2]} {q0[3]} {q0[4]} {q0[5]} {q0[6]}\n")

     # Publicar mensaje y marcadores
     pub.publish(jstate)
     bmarker.publish()
     bmarker_des.publish()

     # Incrementar el tiempo
     t += 1.0 / rate.sleep_dur.to_sec()

     # Esperar la próxima iteración
     rate.sleep()

    # Cerrar archivos al terminar
    fqact.close()
    fqdes.close()
    fxact.close()
    fxdes.close()